function getFibonacci(counter){
    var first = 0;
    var second = 1;
    var returnString = first +', '+second;
    for(i = 1; i<9; i++){
        a = first + second;
        returnString = returnString +', '+a;
        first = second;
        second = a;
    }
    return returnString;
}

function countBs(text){
    var counter = 0
    for (i = 0; i < text.length; i++){
        if (text[i] === 'B'){
            counter++
        }
    }
    return counter;
}

function countChar(text, cha){
    var counter = 0
    for (i = 0; i < text.length; i++){
        if (text[i] === cha){
            counter++
        }
    }
    return counter;
}

console.log(getFibonacci(10));
// → 0, 1, 1, 2, 3, 5, 8, 13, 21, 34
console.log(countBs(prompt('Enter string with few uppercase "B"')));
//console.log(countBs(prompt('Enter string'),prompt('Enter character you want to count')));