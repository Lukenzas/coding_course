Clone/Download and edit the index.html until it will look like in TODO image. No CSS needed!!!
